"""
Module docstring describing the purpose of the module.
"""

JUSTIFIES = {
    '1': 'center',
    '2': 'right',
    '3': 'left',
}
