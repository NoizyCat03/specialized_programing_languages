from Classes.Lab_4.customArt import CustomArt
from Classes.Lab_4.fonts import FONTS
