from Shared.Constants.colors import COLORS, BACKGROUND_COLORS
from Shared.Constants.Fonts import FONTS
from Shared.Constants.justifies import JUSTIFIES
from Shared.Constants.FontsType import FONTS_TYPE
