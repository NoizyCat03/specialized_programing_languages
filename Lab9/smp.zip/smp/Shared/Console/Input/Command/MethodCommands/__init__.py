from Shared.Console.Input.Command.MethodCommands.ConvertStringObjectCommand import ConvertStringObjectCommand
from Shared.Console.Input.Command.MethodCommands.InputBoolCommand import InputBoolCommand
from Shared.Console.Input.Command.MethodCommands.InputFloatNumberCommand import InputFloatNumberCommand
from Shared.Console.Input.Command.MethodCommands.InputIntNumberCommand import InputIntNumberCommand
from Shared.Console.Input.Command.MethodCommands.InputTextCommand import InputTextCommand
from Shared.Console.Input.Command.MethodCommands.SelectObjectWithDictCommand import SelectObjectWithDictCommand

