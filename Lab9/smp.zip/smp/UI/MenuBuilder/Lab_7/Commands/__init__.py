from UI.MenuBuilder.Lab_7.Commands.SetCommands import *
from UI.MenuBuilder.Lab_7.Commands.MethodCommands import *
