from UI.MenuBuilder.Lab_7.Commands.MethodCommands.BuildListCommand import BuildListCommand
from UI.MenuBuilder.Lab_7.Commands.MethodCommands.BuildTableCommand import BuildTableCommand
