from .SetterNum1Command import SetNum1Command
from .SetterNum2Command import SetNum2Command
from .SetterOperationCommand import SetOperatorCommand
from .SetterRoundCommand import SetCustomRoundCommand
from .CalcCommand import CalcCommand
