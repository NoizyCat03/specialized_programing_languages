from UI.MenuBuilder.Lab_6.MenuLab6 import MenuLab6
