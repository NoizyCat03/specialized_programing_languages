from UI.MenuBuilder.Lab_3.Commands.MethodCommands import *
from UI.MenuBuilder.Lab_3.Commands.SetCommands import *
